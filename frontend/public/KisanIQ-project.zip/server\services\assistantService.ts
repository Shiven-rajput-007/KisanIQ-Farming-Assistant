import { db } from '../db/index.js';
import { weatherService } from './weatherService.js';
import { marketService } from './marketService.js';
import { nluEngine, NLUResult, INDIAN_AGRI_HUBS } from './nluEngine.js';

export interface AssistantResponse {
  reply: string;
  intent: string;
  entities: Record<string, any>;
  detectedLanguage: string;
  action?: {
    type: string;
    requiresConfirmation: boolean;
    payload?: any;
    summary: string;
  };
}

export class AssistantService {
  async processQuery(
    farmerId: string = 'farmer_ramesh',
    userQuery: string,
    contextInfo?: {
      activeLocation?: { district?: string; state?: string; latitude?: number; longitude?: number };
      role?: string;
      language?: string;
    }
  ): Promise<AssistantResponse> {
    const sessionId = farmerId || 'guest_user';
    const nluResult: NLUResult = nluEngine.analyze(userQuery, sessionId);
    const { intent, entities, detectedLanguage } = nluResult;
    const isHindi = detectedLanguage === 'hi' || (contextInfo?.language === 'hi' && detectedLanguage !== 'en');

    // 1. Fetch user/farmer crop & location context from DB if exists
    let farmerCrop: any = { name: 'Wheat', variety: 'HD-2967', current_stage: 'vegetative', days_old: 60 };
    let userLat = contextInfo?.activeLocation?.latitude || 26.2183;
    let userLon = contextInfo?.activeLocation?.longitude || 78.1828;
    let userDistrict = contextInfo?.activeLocation?.district || 'Gwalior';
    let userState = contextInfo?.activeLocation?.state || 'Madhya Pradesh';

    if (farmerId && farmerId !== 'guest_user') {
      try {
        const [cropRes, farmerRes] = await Promise.all([
          db.query('SELECT * FROM crops WHERE farmer_id = $1 ORDER BY created_at DESC LIMIT 1', [farmerId]),
          db.query('SELECT district, state, latitude, longitude FROM farmers WHERE id = $1', [farmerId]),
        ]);
        if (cropRes.rows.length > 0) farmerCrop = cropRes.rows[0];
        if (farmerRes.rows.length > 0) {
          const f = farmerRes.rows[0];
          if (!contextInfo?.activeLocation?.latitude && f.latitude) userLat = Number(f.latitude);
          if (!contextInfo?.activeLocation?.longitude && f.longitude) userLon = Number(f.longitude);
          if (!contextInfo?.activeLocation?.district && f.district) userDistrict = f.district;
          if (!contextInfo?.activeLocation?.state && f.state) userState = f.state;
        }
      } catch (e) {
        console.warn('[AssistantService] Context fetch error:', e);
      }
    }

    // Determine targeted coordinates: if user mentioned a specific city, use that city!
    const targetLat = entities.coordinates?.lat || userLat;
    const targetLon = entities.coordinates?.lon || userLon;
    const targetDistrict = entities.location || userDistrict;
    const targetState = entities.state || userState;
    const selectedCrop = entities.crop || farmerCrop.name || 'Wheat';

    let reply = '';
    let action: AssistantResponse['action'] = undefined;

    // -------------------------------------------------------------
    // INTENT DISPATCHER
    // -------------------------------------------------------------
    switch (intent) {
      case 'GREETING': {
        reply = isHindi
          ? `नमस्ते! मैं किसानIQ कृषि सहायक हूँ। मैं आपके क्षेत्र (${targetDistrict}) के मौसम, ${selectedCrop} के मंडी भाव, फसल सलाह और सीधी बिक्री में आपकी सहायता कर सकता हूँ। आज आप क्या जानना चाहते हैं?`
          : `Hello! I am KisanIQ Farming Assistant. I can help you with live weather in ${targetDistrict}, ${selectedCrop} mandi rates, crop advisory, and marketplace orders. How can I assist you today?`;
        break;
      }

      case 'WEATHER': {
        const weather = await weatherService.getWeather(targetLat, targetLon);
        const { current, forecast } = weather;
        const tomorrow = forecast[1] || forecast[0] || { rainProbability: 10, high: 32, low: 18, conditions: 'Partly Cloudy' };

        if (entities.timeframe === 'tomorrow') {
          if (tomorrow.rainProbability >= 40) {
            reply = isHindi
              ? `कल ${targetDistrict} में बारिश की **${tomorrow.rainProbability}% संभावना** है (तापमान ${tomorrow.high}°C / ${tomorrow.low}°C)। मौसम को देखते हुए कल तक सिंचाई टालें और जल निकासी दुरुस्त रखें।`
              : `Tomorrow in ${targetDistrict}, there is a **${tomorrow.rainProbability}% chance of rain** (High: ${tomorrow.high}°C, Low: ${tomorrow.low}°C). We recommend postponing irrigation and ensuring field drainage.`;
          } else {
            reply = isHindi
              ? `कल ${targetDistrict} में मौसम मुख्य रूप से साफ रहेगा। बारिश की संभावना केवल **${tomorrow.rainProbability}%** है। अधिकतम तापमान ${tomorrow.high}°C और न्यूनतम ${tomorrow.low}°C रहेगा।`
              : `Tomorrow in ${targetDistrict}, the weather will be mostly clear with only **${tomorrow.rainProbability}% chance of rain**. High will be around ${tomorrow.high}°C and low around ${tomorrow.low}°C.`;
          }
        } else if (entities.timeframe === 'forecast') {
          const daysText = forecast
            .slice(0, 3)
            .map((f: any) => `${f.day}: ${f.high}°C / ${f.low}°C (${f.rainProbability}% rain)`)
            .join(' | ');
          reply = isHindi
            ? `${targetDistrict} के लिए अगले 3 दिनों का पूर्वानुमान: ${daysText}। वर्तमान तापमान ${current.temperature}°C और नमी ${current.humidity}% है।`
            : `Next 3-day forecast for ${targetDistrict}: ${daysText}. Current temperature is ${current.temperature}°C with ${current.humidity}% humidity.`;
        } else {
          reply = isHindi
            ? `${targetDistrict} में आज का तापमान **${current.temperature}°C** है (नमी: ${current.humidity}%, हवा: ${current.windSpeed} km/h)। स्थिति: ${current.condition}। कल बारिश की संभावना ${tomorrow.rainProbability}% है।`
            : `Today in ${targetDistrict}, the temperature is **${current.temperature}°C** with **${current.humidity}% humidity** and wind speed of ${current.windSpeed} km/h. Conditions: ${current.condition}. Tomorrow's rain probability is ${tomorrow.rainProbability}%.`;
        }
        break;
      }

      case 'LOCATION_CHANGE': {
        if (entities.location && entities.coordinates) {
          action = {
            type: 'CHANGE_LOCATION',
            requiresConfirmation: true,
            payload: {
              district: entities.location,
              state: entities.state || 'Madhya Pradesh',
              latitude: entities.coordinates.lat,
              longitude: entities.coordinates.lon,
            },
            summary: isHindi
              ? `सक्रिय स्थान बदलकर ${entities.location}, ${entities.state} करें`
              : `Change active location to ${entities.location}, ${entities.state}`,
          };
          reply = isHindi
            ? `मैंने आपके द्वारा चुना गया स्थान **${entities.location}, ${entities.state}** पहचाना है। क्या आप अपना सक्रिय स्थान अपडेट करना चाहते हैं?`
            : `I identified your request to set location to **${entities.location}, ${entities.state}**. Would you like me to update your active location?`;
        } else {
          reply = isHindi
            ? `आप कौन सा जिला या शहर सेट करना चाहते हैं? (उदा. इंदौर, कानपुर, लखनऊ, भोपाल, ग्वालियर)`
            : `Which district or city would you like to set? (e.g. Indore, Kanpur, Lucknow, Bhopal, Gwalior)`;
        }
        break;
      }

      case 'USE_GPS_LOCATION': {
        action = {
          type: 'TRIGGER_GPS',
          requiresConfirmation: false,
          summary: isHindi ? 'ब्राउज़र GPS से स्थान पहचानें' : 'Detect location via browser GPS',
        };
        reply = isHindi
          ? `आपके वर्तमान GPS निर्देशांक पहचाने जा रहे हैं। कृपया स्क्रीन पर लोकेशन अनुमति दें।`
          : `Detecting your precise GPS location now. Please grant browser location permission if prompted.`;
        break;
      }

      case 'MANDI_PRICE': {
        const comp = await marketService.getMarketComparison(
          farmerId,
          selectedCrop,
          100,
          targetLat,
          targetLon,
          targetDistrict,
          targetState
        );
        const top = comp.markets[0];
        if (top) {
          reply = isHindi
            ? `${top.name} (${top.district || targetDistrict}) में **${selectedCrop}** का मॉडल भाव **₹${top.price.toLocaleString('en-IN')}/क्विंटल** है (दूरी: ${top.distance} किमी, परिवहन: ₹${top.transportCost})। शुद्ध अनुमानित रिटर्न ₹${top.netReturn.toLocaleString('en-IN')} है। स्रोत: ${top.source}।`
            : `At ${top.name} (${top.district || targetDistrict}), the current benchmark price for **${selectedCrop}** is **₹${top.price.toLocaleString('en-IN')}/quintal** (Distance: ${top.distance} km, Freight: ₹${top.transportCost}). Estimated net return: ₹${top.netReturn.toLocaleString('en-IN')}. Source: ${top.source}.`;
        } else {
          reply = isHindi
            ? `क्षमा करें, ${targetDistrict} क्षेत्र के लिए ${selectedCrop} के लाइव मंडी भाव अभी उपलब्ध नहीं हैं।`
            : `Currently, live mandi rates for ${selectedCrop} around ${targetDistrict} are unavailable.`;
        }
        break;
      }

      case 'MARKET_RECOMMENDATION': {
        const comp = await marketService.getMarketComparison(
          farmerId,
          selectedCrop,
          100,
          targetLat,
          targetLon,
          targetDistrict,
          targetState
        );
        const top = comp.markets[0];
        reply = isHindi
          ? `किसानIQ विश्लेषण: आज सबसे बेहतर व्यावहारिक विकल्प **${top.name}** है (भाव: ₹${top.price}/q, शुद्ध लाभ: ₹${top.netReturn.toLocaleString('en-IN')})। किसानIQ सुझाव देता है कि 60% मात्रा अभी बेचें और 40% भाव उछाल की प्रतीक्षा में रोकें।`
          : `KisanIQ Recommendation: The best practical option today is **${top.name}** (Price: ₹${top.price}/q, Net Realization: ₹${top.netReturn.toLocaleString('en-IN')}). Our decision engine advises selling 60% now and holding 40% to balance market risk.`;
        break;
      }

      case 'IRRIGATION_ADVICE': {
        const weather = await weatherService.getWeather(targetLat, targetLon);
        const tomorrow = weather.forecast[1] || weather.forecast[0];
        if (tomorrow && tomorrow.rainProbability >= 40) {
          reply = isHindi
            ? `आज फसल में पानी न दें। कल ${targetDistrict} में **${tomorrow.rainProbability}% बारिश** की संभावना है। फसल (${farmerCrop.name}) की वर्तमान ${farmerCrop.current_stage} अवस्था में अधिक पानी से जड़ सड़न हो सकती है।`
            : `Do not irrigate today. Rain probability tomorrow in ${targetDistrict} is **${tomorrow.rainProbability}%**. Over-watering during the ${farmerCrop.current_stage} stage of ${farmerCrop.name} can risk root disease.`;
        } else {
          reply = isHindi
            ? `अगले 2 दिनों में बारिश की संभावना कम है। यदि मिट्टी की ऊपरी सतह 2 इंच तक सूखी है, तो शाम के समय हल्की सिंचाई करें।`
            : `Rain probability is low for the next 2 days. If topsoil moisture is below 2 inches, proceed with light irrigation during morning or evening hours.`;
        }
        break;
      }

      case 'DISEASE_PEST': {
        const weather = await weatherService.getWeather(targetLat, targetLon);
        reply = isHindi
          ? `वर्तमान नमी (${weather.current.humidity}%) में **${selectedCrop}** में फफूंद या कीट (जैसे पीला रतुआ या माहू) का खतरा बढ़ सकता है। पत्तों के नीचे पीले पाउडर या धब्बे दिखें तो प्रोपिकोनाजोल (Propiconazole 25% EC) 1ml/लीटर पानी की दर से छिड़काव करें।`
          : `At current humidity levels (${weather.current.humidity}%), **${selectedCrop}** may be susceptible to fungal or rust symptoms (e.g. Yellow Rust / Aphids). Inspect leaf undersides; if spotted, spray Propiconazole 25% EC at 1 ml per liter of water.`;
        break;
      }

      case 'CROP_RECOMMENDATION': {
        reply = isHindi
          ? `आपकी ${farmerCrop.name} फसल (${farmerCrop.variety || 'Certified'}) ${farmerCrop.days_old || 60} दिन पुरानी है और ${farmerCrop.current_stage} चरण में है। मौसम अनुकूल है। समय पर निराई-गुड़ाई करें और यूरिया की दूसरी खुराक सिंचाई के साथ दें।`
          : `Your ${farmerCrop.name} crop (${farmerCrop.variety || 'Certified'}) is currently ${farmerCrop.days_old || 60} days old in ${farmerCrop.current_stage} stage. Weather conditions are supportive. Ensure balanced nitrogen application and timely weed management.`;
        break;
      }

      case 'SELLER_SEARCH': {
        const targetLoc = entities.location;
        let listingsRes;
        let isLocationFiltered = false;

        if (targetLoc) {
          listingsRes = await db.query(
            `SELECT l.*, f.name as farmer_name, f.district as farmer_district, f.phone as farmer_phone
             FROM crop_listings l
             JOIN farmers f ON l.farmer_id = f.id
             WHERE l.status = 'active' AND l.crop_name ILIKE $1 AND (l.location ILIKE $2 OR f.district ILIKE $2)
             ORDER BY l.created_at DESC LIMIT 4`,
            [`%${selectedCrop}%`, `%${targetLoc}%`]
          );
          if (listingsRes.rows.length > 0) {
            isLocationFiltered = true;
          }
        }

        if (!listingsRes || listingsRes.rows.length === 0) {
          listingsRes = await db.query(
            `SELECT l.*, f.name as farmer_name, f.district as farmer_district, f.phone as farmer_phone
             FROM crop_listings l
             JOIN farmers f ON l.farmer_id = f.id
             WHERE l.status = 'active' AND l.crop_name ILIKE $1
             ORDER BY l.created_at DESC LIMIT 4`,
            [`%${selectedCrop}%`]
          );
        }

        if (listingsRes.rows.length > 0) {
          const listText = listingsRes.rows
            .map(
              (r: any) =>
                `• ${r.farmer_name} (${r.location || r.farmer_district}): ${r.quantity_quintals}q @ ₹${r.price_per_quintal}/q`
            )
            .join('\n');

          if (isLocationFiltered && targetLoc) {
            reply = isHindi
              ? `${targetLoc} के निकटवर्ती क्षेत्रों में ${selectedCrop} बेचने वाले सत्यापित किसान:\n${listText}\nआप मार्केटप्लेस में सीधे इनसे खरीद सकते हैं।`
              : `Verified farmers selling ${selectedCrop} near ${targetLoc}:\n${listText}\nYou can purchase directly from them via the Marketplace.`;
          } else {
            reply = isHindi
              ? `${targetLoc ? `${targetLoc} के आसपास एवं ` : ''}सत्यापित किसान जो ${selectedCrop} बेच रहे हैं:\n${listText}\nआप मार्केटप्लेस में सीधे इनसे खरीद सकते हैं।`
              : `Verified farmers selling ${selectedCrop}${targetLoc ? ` in/around ${targetLoc}` : ''}:\n${listText}\nYou can purchase directly via the Marketplace.`;
          }
        } else {
          reply = isHindi
            ? `वर्तमान में ${selectedCrop} के लिए कोई सक्रिय लिस्टिंग नहीं मिली। खरीदार मार्केटप्लेस में अन्य फसलें देख सकते हैं।`
            : `Currently, no direct farmer listings were found for ${selectedCrop}. You can browse all available crops in the Marketplace.`;
        }
        break;
      }

      case 'MY_LISTINGS': {
        const res = await db.query(
          `SELECT * FROM crop_listings WHERE farmer_id = $1 ORDER BY created_at DESC LIMIT 5`,
          [farmerId]
        );
        if (res.rows.length > 0) {
          const items = res.rows
            .map((r: any) => `• ${r.crop_name} (${r.variety}): ${r.quantity_quintals}q @ ₹${r.price_per_quintal}/q [${r.status}]`)
            .join('\n');
          reply = isHindi
            ? `आपकी सक्रिय फसल लिस्टिंग:\n${items}`
            : `Your published crop listings:\n${items}`;
        } else {
          reply = isHindi
            ? `आपकी अभी कोई फसल लिस्टिंग नहीं है। आप बोलकर या मार्केट सेक्शन से नई फसल लिस्ट कर सकते हैं।`
            : `You do not have any published crop listings yet. You can create one by speaking or visiting the Sell section.`;
        }
        break;
      }

      case 'CREATE_LISTING': {
        const qty = entities.quantity || 10;
        const price = entities.price || 2500;
        const crop = selectedCrop;
        const grade = entities.grade || 'Grade A';
        const variety = entities.variety || 'Certified Sharbati';

        action = {
          type: 'CREATE_LISTING',
          requiresConfirmation: true,
          payload: {
            cropName: crop,
            variety,
            quantityQuintals: qty,
            pricePerQuintal: price,
            qualityGrade: grade,
            location: `${userDistrict}, ${userState}`,
            description: `Naturally harvested ${crop} from ${userDistrict}`,
          },
          summary: isHindi
            ? `${qty} क्विंटल ${crop} (दर: ₹${price}/q) की लिस्टिंग प्रकाशित करें`
            : `Publish listing: ${qty}q of ${crop} at ₹${price}/quintal`,
        };

        reply = isHindi
          ? `मैंने आपकी लिस्टिंग तैयार कर ली है: **${crop} — ${qty} क्विंटल — ₹${price.toLocaleString('en-IN')}/क्विंटल**। क्या मैं इसे मार्केटप्लेस में प्रकाशित कर दूँ?`
          : `I have prepared your listing: **${crop} — ${qty} quintals — ₹${price.toLocaleString('en-IN')}/quintal**. Should I publish this to the marketplace?`;
        break;
      }

      case 'MY_ORDERS': {
        const ordersRes = await db.query(
          `SELECT * FROM marketplace_orders WHERE buyer_id = $1 OR farmer_id = $1 ORDER BY created_at DESC LIMIT 3`,
          [farmerId]
        );
        if (ordersRes.rows.length > 0) {
          const ordText = ordersRes.rows
            .map((o: any) => `• Order #${o.id.slice(-6)}: ${o.quantity_quintals}q ${o.crop_name} (Status: ${o.status.toUpperCase()}, Tracking: ${o.tracking_code})`)
            .join('\n');
          reply = isHindi ? `आपके हाल के ऑर्डर:\n${ordText}` : `Your recent orders:\n${ordText}`;
        } else {
          reply = isHindi
            ? `वर्तमान में आपका कोई सक्रिय ऑर्डर नहीं है।`
            : `You currently have no active marketplace orders.`;
        }
        break;
      }

      case 'LOGISTICS_TRACKING': {
        const trackRes = await db.query(
          `SELECT * FROM marketplace_orders WHERE (buyer_id = $1 OR farmer_id = $1) AND status != 'delivered' ORDER BY created_at DESC LIMIT 1`,
          [farmerId]
        );
        if (trackRes.rows.length > 0) {
          const ord = trackRes.rows[0];
          reply = isHindi
            ? `ऑर्डर #${ord.id.slice(-6)} का स्टेटस: **${ord.status.toUpperCase()}**। ट्रैकिंग कोड: **${ord.tracking_code}**। डिलीवरी पता: ${ord.delivery_address}।`
            : `Order #${ord.id.slice(-6)} status: **${ord.status.toUpperCase()}**. Tracking code: **${ord.tracking_code}**. Delivery address: ${ord.delivery_address}.`;
        } else {
          reply = isHindi
            ? `आपका कोई शिपमेंट रास्ते में नहीं है। सभी पूर्व ऑर्डर डिलीवर हो चुके हैं।`
            : `You have no active shipments in transit. All previous orders have been completed.`;
        }
        break;
      }

      case 'CROP_ROTATION': {
        reply = isHindi
          ? `गेहूं या सरसों की कटाई के बाद आप **सोयाबीन (JS-2034)** या **मूंग / उड़द** लगा सकते हैं। दलहनी फसलें मिट्टी में प्राकृतिक नाइट्रोजन जोड़ती हैं और अगली रबी फसल की उत्पादकता 15-20% बढ़ाती हैं।`
          : `Following wheat or mustard harvest, planting **Soybean (JS-2034)** or **Moong/Pulses** is ideal. Legumes fix biological nitrogen, boosting subsequent rabi crop yield by 15-20%.`;
        break;
      }

      default: {
        reply = isHindi
          ? `नमस्ते! मैं मौसम, सिंचाई सलाह, ${selectedCrop} के मंडी भाव, और फसल लिस्टिंग में आपकी सहायता कर सकता हूँ। आप जैसे चाहें हिंदी, अंग्रेज़ी या हिंग्लिश में पूछ सकते हैं।`
          : `Hello! I can help you with weather, irrigation advisory, mandi rates for ${selectedCrop}, and marketplace trade. Feel free to speak or type in Hindi, English, or Hinglish.`;
        break;
      }
    }

    // Save chat interaction to database
    try {
      const userMsgId = `msg_${Date.now()}_u`;
      const asstMsgId = `msg_${Date.now()}_a`;
      await db.query(
        `INSERT INTO chat_messages (id, farmer_id, role, content) VALUES ($1, $2, $3, $4)`,
        [userMsgId, farmerId === 'guest_user' ? null : farmerId, 'user', userQuery]
      );
      await db.query(
        `INSERT INTO chat_messages (id, farmer_id, role, content) VALUES ($1, $2, $3, $4)`,
        [asstMsgId, farmerId === 'guest_user' ? null : farmerId, 'assistant', reply]
      );
    } catch (dbErr) {
      console.warn('[AssistantService] Failed to persist chat messages:', dbErr);
    }

    return {
      reply,
      intent,
      entities,
      detectedLanguage,
      action,
    };
  }

  async executeAction(
    farmerId: string,
    actionType: string,
    payload: any
  ): Promise<{ success: boolean; message: string; result?: any }> {
    switch (actionType) {
      case 'CHANGE_LOCATION': {
        const { district, state, latitude, longitude } = payload;
        if (farmerId && farmerId !== 'guest_user') {
          await db.query(
            `UPDATE farmers SET district = $1, state = $2, latitude = $3, longitude = $4, updated_at = NOW() WHERE id = $5`,
            [district, state, latitude, longitude, farmerId]
          );
        }
        return {
          success: true,
          message: `Location successfully updated to ${district}, ${state}.`,
          result: { district, state, latitude, longitude },
        };
      }

      case 'CREATE_LISTING': {
        const id = `lst_${Date.now()}`;
        const { cropName, variety, quantityQuintals, pricePerQuintal, qualityGrade, location, description } = payload;
        await db.query(
          `INSERT INTO crop_listings (id, farmer_id, crop_name, variety, quantity_quintals, price_per_quintal, quality_grade, location, description, status)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'active')`,
          [
            id,
            farmerId === 'guest_user' ? 'farmer_ramesh' : farmerId,
            cropName,
            variety || 'Certified',
            Number(quantityQuintals),
            Number(pricePerQuintal),
            qualityGrade || 'Grade A',
            location || 'Madhya Pradesh',
            description || '',
          ]
        );
        return {
          success: true,
          message: `Crop listing for ${quantityQuintals}q of ${cropName} published to marketplace!`,
          result: { id, cropName, quantityQuintals, pricePerQuintal },
        };
      }

      default:
        throw new Error(`Unknown action type: ${actionType}`);
    }
  }

  async getHistory(farmerId: string = 'farmer_ramesh') {
    const res = await db.query(
      `SELECT * FROM chat_messages WHERE farmer_id = $1 OR farmer_id IS NULL ORDER BY created_at ASC LIMIT 50`,
      [farmerId]
    );
    return res.rows;
  }
}

export const assistantService = new AssistantService();
