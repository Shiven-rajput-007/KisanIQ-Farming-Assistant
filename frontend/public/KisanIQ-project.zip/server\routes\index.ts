import { Router } from 'express';
import { db } from '../db/index.js';
import authRoutes from './authRoutes.js';
import farmerRoutes from './farmerRoutes.js';
import cropRoutes from './cropRoutes.js';
import weatherRoutes from './weatherRoutes.js';
import marketRoutes from './marketRoutes.js';
import recommendationRoutes from './recommendationRoutes.js';
import riskRoutes from './riskRoutes.js';
import assistantRoutes from './assistantRoutes.js';
import notificationRoutes from './notificationRoutes.js';
import orderRoutes from './orderRoutes.js';
import listingRoutes from './listingRoutes.js';
import marketplaceRoutes from './marketplaceRoutes.js';
import { getDashboard } from '../controllers/dashboardController.js';
import { optionalAuth } from '../middleware/auth.js';

const router = Router();

// Health check
router.get('/health', async (_req, res) => {
  try {
    const dbTest = await db.query('SELECT 1 as alive');
    res.json({
      status: 'ok',
      service: 'KisanIQ Backend API',
      database: db.type,
      databaseConnected: dbTest.rows?.[0]?.alive === 1,
      uptime: process.uptime(),
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    res.status(500).json({
      status: 'error',
      service: 'KisanIQ Backend API',
      database: db.type,
      error: err.message,
    });
  }
});

// Dashboard briefing
router.get('/dashboard', optionalAuth, getDashboard);

// Sub-routers
router.use('/auth', authRoutes);
router.use('/farmer', farmerRoutes);
router.use('/crops', cropRoutes);
router.use('/weather', weatherRoutes);
router.use('/market', marketRoutes);
router.use('/recommendations', recommendationRoutes);
router.use('/risk', riskRoutes);
router.use('/assistant', assistantRoutes);
router.use('/notifications', notificationRoutes);
router.use('/orders', orderRoutes);
router.use('/listings', listingRoutes);
router.use('/marketplace', marketplaceRoutes);

export default router;
