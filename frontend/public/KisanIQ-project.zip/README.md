# KisanIQ — Intelligent Digital Farming Assistant (Full-Stack)

> **“KisanIQ does not just show farming data. KisanIQ converts farming data into clear decisions and actions.”**  
> Core flow: **DATA → INTELLIGENCE → DECISION → ACTION**  
> Primary farmer question: **“Aaj mujhe kya karna hai?”**

---

## 🏗️ Architecture

```
React 18 + Vite + Tailwind Frontend (Port 5173)
        │
        │ HTTP REST APIs (JSON / JWT)
        ▼
Node.js + Express + TypeScript Backend (Port 8000)
        │
   ┌────┴────────────────────────┬────────────────────────┐
   ▼                             ▼                        ▼
PostgreSQL Database        Open-Meteo API           Explainable Decision Engine
(Embedded PGlite or       (Live agricultural       (Rules + FAO-56 models +
External PostgreSQL)       weather & forecast)      Mandi net return optimization)
```

---

## 🚀 Quick Start Commands

### 1. Install Dependencies
```bash
# In server directory
cd server
npm install

# In frontend directory
cd ../frontend
npm install
```

### 2. Start Both Services

**Start Backend (Port 8000):**
```bash
cd server
npm run dev
```

**Start Frontend (Port 5173):**
```bash
cd frontend
npm run dev
```

The application will be accessible at:
- **Frontend UI**: [http://localhost:5173/](http://localhost:5173/)
- **Backend API**: [http://localhost:8000/api/health](http://localhost:8000/api/health)

---

## 🗄️ Database

KisanIQ uses **PostgreSQL**.
- **Out of the box**: Operates via embedded PostgreSQL (`@electric-sql/pglite`) persisting data to `./server/db/data`. No external database installation or Docker container is required.
- **External PostgreSQL**: To connect to external PostgreSQL (e.g. Supabase, Neon, AWS RDS, or local PostgreSQL service), simply set in `server/.env`:
  ```ini
  DATABASE_URL=postgresql://username:password@localhost:5432/kisaniq_db
  ```
- **Database Schema**: Stored in `server/db/schema.sql` (15 tables: users, farmers, farms, fields, crops, crop_stages, crop_actions, markets, market_prices, recommendations, alerts, notifications, chat_messages, orders, shipments, vehicles, weather_cache).
- **Run Seeding**:
  ```bash
  cd server
  npm run seed
  ```

---

## 🧪 Running the End-to-End Test Suite

Run the automated integration test suite covering all 14 critical user journeys:
```bash
cd server
npx tsx test-suite.ts
```
Expected output:
```
Total: 14 | Passed: 14 | Failed: 0
```

---

## 📡 API Endpoints Reference

| Category | Method | Endpoint | Description |
|---|---|---|---|
| **Health** | `GET` | `/api/health` | Backend status, DB connection, uptime |
| **Dashboard** | `GET` | `/api/dashboard` | Aggregated daily briefing for "Aaj Kya Karein" |
| **Auth** | `POST` | `/api/auth/register` | Register new farmer account |
| **Auth** | `POST` | `/api/auth/login` | Login with phone & password, returns JWT |
| **Auth** | `GET` | `/api/auth/me` | Authenticated farmer profile |
| **Farmer** | `GET` | `/api/farmer/profile` | Profile, farm size, soil, irrigation source |
| **Farmer** | `PUT` | `/api/farmer/profile` | Update farmer & farm profile |
| **Farmer** | `POST` | `/api/farmer/onboarding` | 6-step onboarding submission |
| **Weather** | `GET` | `/api/weather/current` | Live Open-Meteo temp, rain %, humidity, agricultural notes |
| **Crops** | `GET` | `/api/crops` | Farmer crops, growth stage timeline, action tasks |
| **Crops** | `POST` | `/api/crops` | Add new crop |
| **Market** | `GET` | `/api/market/comparison` | Mandi prices, transport costs, net return, partial selling |
| **Orders** | `POST` | `/api/market/orders` | Execute sale, book transport & create tracking code |
| **Orders** | `GET` | `/api/orders` | Active sell orders & logistics shipment tracking |
| **Decision Engine**| `GET` | `/api/recommendations/daily` | Explainable actions with "Kyun?" data points |
| **Decision Engine**| `POST` | `/api/recommendations/:id/complete`| Mark action completed in database |
| **Risk** | `GET` | `/api/risk/assessment` | Dynamic risk score (0-100) across 4 categories |
| **Assistant** | `POST` | `/api/assistant/chat` | Context-aware agricultural assistant in Hindi/English |
| **Assistant** | `GET` | `/api/assistant/history` | Chat message history |
| **Notifications**| `GET` | `/api/notifications` | Real-time weather, price, and crop alerts |
| **Notifications**| `PUT` | `/api/notifications/:id/read` | Mark single notification as read |

---

## 🧠 Explainable Decision Engine & ML-Readiness

The Decision Engine (`server/services/decisionEngine.ts`) applies transparent agricultural rules:
1. **Irrigation Model**: Cross-references Open-Meteo 48-hour precipitation probability and FAO-56 crop evapotranspiration with current soil type and crop stage. Recommends postponing irrigation if rain $\ge 50\%$ or precipitation $\ge 4\text{mm}$, avoiding root rot and waterlogging.
2. **Disease Model**: Evaluates relative humidity and temperature thresholds conducive to fungal rusts (*Puccinia striiformis*) and generates crop leaf inspection advisories.
3. **Mandi Economics Model**:
   $$\text{Net Return} = (\text{Price} \times \text{Quantity}) - (\text{Transport} + \text{Commission} + \text{Loading} + \text{Wastage})$$
   Identifies the best practical market option rather than misleading gross price.
4. **Partial Selling Strategy**: Dynamically splits harvest (e.g. 60% immediate sale, 40% strategic hold) to minimize downside market risk while retaining price upside.

The engine is built modularly with clean interfaces so rule-based functions can be progressively upgraded with machine learning regression / classification models.

---

## 🌐 Multi-Language Support
Full localization supported across **11 Indian languages**:
Hindi (`hi`), English (`en`), Punjabi (`pa`), Marathi (`mr`), Gujarati (`gu`), Bengali (`bn`), Tamil (`ta`), Telugu (`te`), Kannada (`kn`), Malayalam (`ml`), and Odia (`or`).
