import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { WeatherCard } from '@/components/domain/weather-card';
import { AajKyaKarein } from '@/components/domain/aaj-kya-karein';
import { AlertCard } from '@/components/domain/alert-card';
import { FasalBechniCard } from '@/components/domain/fasal-bechni-card';
import { CropCard } from '@/components/domain/crop-card';
import { WhyExplanation } from '@/components/domain/why-explanation';
import { ChatSuggestionChip } from '@/components/domain/chat-suggestion';
import { SectionHeader } from '@/components/ui/section-header';
import { DemoBanner } from '@/components/ui/demo-banner';
import { Skeleton } from '@/components/ui/skeleton';
import { ErrorState } from '@/components/ui/error-state';
import { useDashboard } from '@/hooks/useDashboard';
import { recommendationApi } from '@/api';
import { mockChatSuggestions } from '@/services/mock/mock-data';
import { ROUTES } from '@/routes/paths';

export default function HomePage() {
  const { t } = useTranslation('home');
  const navigate = useNavigate();
  const { data, isLoading, error, isFallback, refetch } = useDashboard();
  const [showWhy, setShowWhy] = useState(false);
  const [selectedActionId, setSelectedActionId] = useState<string | null>(null);

  if (isLoading) {
    return (
      <div className="space-y-5">
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-56 w-full" />
        <Skeleton className="h-28 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  if (error && !data) {
    return <ErrorState onRetry={refetch} description={error} />;
  }

  if (!data) return null;

  const { weather, recommendations, alerts, bestMarket, crops, farmingImplications } = data;
  const primaryAction = recommendations.find(r => r.id === selectedActionId) || recommendations[0];
  const farmingNote = farmingImplications?.[0]?.actionKey || t('weather.farming_note');

  const handleActionComplete = async (action: any) => {
    if (action.category === 'market') {
      navigate(ROUTES.MARKET);
    } else {
      try {
        await recommendationApi.completeAction(action.id);
        refetch();
      } catch (e) {
        console.warn('Could not complete action:', e);
      }
    }
  };

  return (
    <div className="space-y-5">
      {isFallback && <DemoBanner className="mb-2" />}

      {/* Real Weather */}
      <WeatherCard
        weather={weather}
        farmingNote={farmingNote}
        onClick={() => navigate(ROUTES.WEATHER)}
      />

      {/* AAJ KYA KAREIN - Explainable Decision Engine Hero */}
      <AajKyaKarein
        actions={recommendations}
        onWhyClick={(action) => {
          setSelectedActionId(action.id);
          setShowWhy(prev => (selectedActionId === action.id ? !prev : true));
        }}
        onActionClick={handleActionComplete}
      />

      {/* Why explanation (transparent, data-backed) */}
      {showWhy && primaryAction?.whyExplanation && (
        <WhyExplanation
          explanation={primaryAction.whyExplanation}
          className="animate-in slide-in-from-bottom-2"
        />
      )}

      {/* Real Alerts */}
      {alerts && alerts.length > 0 && (
        <AlertCard
          alert={alerts[0]}
          onDetails={() => navigate(ROUTES.RISK)}
        />
      )}

      {/* Fasal Bechni Hai - Market Intelligence */}
      {bestMarket && (
        <FasalBechniCard
          cropName={crops[0]?.name || 'Wheat'}
          bestMarketName={bestMarket.name}
          bestPrice={bestMarket.price}
          riskLevel={bestMarket.riskLevel}
          onClick={() => navigate(ROUTES.MARKET)}
        />
      )}

      {/* Crop Overview */}
      <div>
        <SectionHeader
          title={t('crop_overview.title')}
          icon={<span className="text-lg">🌾</span>}
          action={{
            label: t('crop_overview.view_details'),
            onClick: () => navigate(ROUTES.MERI_FASAL),
          }}
        />
        <div className="space-y-3">
          {crops.map((crop) => (
            <CropCard
              key={crop.id}
              crop={crop}
              onClick={() => navigate(ROUTES.MERI_FASAL)}
            />
          ))}
        </div>
      </div>

      {/* Ask KisanIQ */}
      <div>
        <SectionHeader
          title={t('assistant.title')}
          icon={<span className="text-lg">🤖</span>}
          action={{
            label: t('common:buttons.view_all'),
            onClick: () => navigate(ROUTES.ASSISTANT),
          }}
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {mockChatSuggestions.slice(0, 4).map((suggestion) => (
            <ChatSuggestionChip
              key={suggestion.id}
              suggestion={suggestion}
              onClick={() => navigate(ROUTES.ASSISTANT, { state: { initialQuery: suggestion.query } })}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
