import { useState, useEffect, useCallback } from 'react';
import { riskApi } from '@/api';
import type { RiskAssessment } from '@/types';
import { mockRiskAssessment } from '@/services/mock/mock-data';

export function useRisk() {
  const [data, setData] = useState<RiskAssessment | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isFallback, setIsFallback] = useState(false);

  const fetchRisk = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await riskApi.getAssessment();
      setData(res.assessment);
      setIsFallback(false);
    } catch (err: any) {
      console.warn('[useRisk] API fetch failed, using fallback mock data:', err.message);
      setIsFallback(true);
      setError(err.message);
      setData(mockRiskAssessment);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRisk();
  }, [fetchRisk]);

  return { data, isLoading, error, isFallback, refetch: fetchRisk };
}
