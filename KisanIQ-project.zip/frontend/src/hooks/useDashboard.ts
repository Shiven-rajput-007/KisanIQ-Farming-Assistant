import { useState, useEffect, useCallback } from 'react';
import { dashboardApi, type DashboardResponse } from '@/api';
import { useActiveLocation } from '@/context/LocationContext';
import {
  mockWeather,
  mockRecommendations,
  mockAlerts,
  mockCrops,
  mockMarketComparison,
} from '@/services/mock/mock-data';

export function useDashboard() {
  const { location } = useActiveLocation();
  const [data, setData] = useState<DashboardResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isFallback, setIsFallback] = useState(false);

  const fetchDashboard = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await dashboardApi.getDashboard({
        lat: location.latitude,
        lon: location.longitude,
        district: location.district,
        state: location.state,
      });
      setData(res);
      setIsFallback(false);
    } catch (err: any) {
      console.warn('[useDashboard] API fetch failed, using fallback mock data:', err.message);
      setIsFallback(true);
      setError(err.message);
      // Fallback
      const bestMarket = mockMarketComparison.markets.find(m => m.isRecommended) || mockMarketComparison.markets[0];
      setData({
        success: true,
        farmer: { id: 'farmer_ramesh', name: 'Ramesh', location: `${location.district || 'Gwalior'}, ${location.state || 'Madhya Pradesh'}` },
        weather: mockWeather,
        forecast: [],
        farmingImplications: [],
        recommendations: mockRecommendations,
        alerts: mockAlerts,
        bestMarket,
        crops: mockCrops,
        lastUpdated: new Date().toISOString(),
      });
    } finally {
      setIsLoading(false);
    }
  }, [location.latitude, location.longitude, location.district, location.state]);

  useEffect(() => {
    fetchDashboard();
  }, [fetchDashboard]);

  return { data, isLoading, error, isFallback, refetch: fetchDashboard };
}
