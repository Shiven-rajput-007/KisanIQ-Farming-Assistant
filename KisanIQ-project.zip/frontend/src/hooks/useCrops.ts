import { useState, useEffect, useCallback } from 'react';
import { cropApi, type CropsResponse } from '@/api';
import { mockCrops, mockCropStages, mockCropActions } from '@/services/mock/mock-data';

export function useCrops() {
  const [data, setData] = useState<CropsResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isFallback, setIsFallback] = useState(false);

  const fetchCrops = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await cropApi.getCrops();
      setData(res);
      setIsFallback(false);
    } catch (err: any) {
      console.warn('[useCrops] API fetch failed, using fallback mock data:', err.message);
      setIsFallback(true);
      setError(err.message);
      setData({
        success: true,
        crops: mockCrops,
        stages: mockCropStages,
        actions: mockCropActions,
      });
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCrops();
  }, [fetchCrops]);

  return { data, isLoading, error, isFallback, refetch: fetchCrops };
}
