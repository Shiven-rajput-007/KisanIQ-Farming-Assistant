import { useState, useEffect, useCallback } from 'react';
import { farmerApi } from '@/api';
import type { Farmer, FarmProfile } from '@/types';
import { mockFarmer, mockFarmProfile } from '@/services/mock/mock-data';

export function useProfile() {
  const [farmer, setFarmer] = useState<Farmer | null>(null);
  const [farmProfile, setFarmProfile] = useState<FarmProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isFallback, setIsFallback] = useState(false);

  const fetchProfile = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await farmerApi.getProfile();
      setFarmer(res.farmer);
      setFarmProfile(res.farmProfile);
      setIsFallback(false);
    } catch (err: any) {
      console.warn('[useProfile] API fetch failed, using fallback mock data:', err.message);
      setIsFallback(true);
      setError(err.message);
      setFarmer(mockFarmer);
      setFarmProfile(mockFarmProfile);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  return { farmer, farmProfile, isLoading, error, isFallback, refetch: fetchProfile };
}
