import { Request, Response, NextFunction } from 'express';
import { verifyToken, TokenPayload } from '../utils/jwt.js';

export interface AuthRequest extends Request {
  user?: TokenPayload;
  userId?: string;
  farmerId?: string;
}

export function authenticate(req: AuthRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ success: false, error: 'Unauthorized: Missing or invalid token' });
    return;
  }

  const token = authHeader.split(' ')[1];
  const payload = verifyToken(token);

  if (!payload) {
    res.status(401).json({ success: false, error: 'Unauthorized: Invalid or expired token' });
    return;
  }

  req.user = payload;
  req.userId = payload.userId;
  req.farmerId = payload.farmerId;
  next();
}

/**
 * Optional authentication middleware: if token present, sets user and farmerId;
 * if not present, sets default farmerId ('farmer_ramesh') so the demo / prototype flows work seamlessly!
 */
export function optionalAuth(req: AuthRequest, _res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    const payload = verifyToken(token);
    if (payload) {
      req.user = payload;
      req.userId = payload.userId;
      req.farmerId = payload.farmerId;
      return next();
    }
  }

  // Fallback to default active farmer
  req.userId = 'user_ramesh';
  req.farmerId = 'farmer_ramesh';
  next();
}
