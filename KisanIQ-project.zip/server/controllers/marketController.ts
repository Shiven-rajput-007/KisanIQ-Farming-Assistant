import { Response } from 'express';
import { marketService } from '../services/marketService.js';
import { AuthRequest } from '../middleware/auth.js';

export async function getMarketComparison(req: AuthRequest, res: Response): Promise<void> {
  try {
    const farmerId = req.farmerId || (req.userId ? `frm_${req.userId}` : 'farmer_ramesh');
    const cropName = (req.query.crop as string) || 'Wheat';
    const quantity = Number(req.query.quantity) || 100;
    const lat = req.query.lat ? Number(req.query.lat) : undefined;
    const lon = (req.query.lon || req.query.lng) ? Number(req.query.lon || req.query.lng) : undefined;
    const district = req.query.district ? String(req.query.district) : undefined;
    const state = req.query.state ? String(req.query.state) : undefined;

    const data = await marketService.getMarketComparison(
      farmerId,
      cropName,
      quantity,
      lat,
      lon,
      district,
      state
    );
    res.json({ success: true, ...data });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export async function createSellOrder(req: AuthRequest, res: Response): Promise<void> {
  try {
    const farmerId = req.farmerId || (req.userId ? `frm_${req.userId}` : 'farmer_ramesh');
    const { marketId, cropName = 'Wheat', quantity, agreedPrice } = req.body;

    if (!marketId || !quantity || !agreedPrice) {
      res.status(400).json({ success: false, error: 'marketId, quantity, and agreedPrice are required' });
      return;
    }

    const order = await marketService.createOrder(
      farmerId,
      marketId,
      cropName,
      Number(quantity),
      Number(agreedPrice)
    );

    res.status(201).json({ success: true, order });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}
