import { Response } from 'express';
import { db } from '../db/index.js';
import { AuthRequest } from '../middleware/auth.js';

export async function getNotifications(req: AuthRequest, res: Response): Promise<void> {
  try {
    const farmerId = req.farmerId || 'farmer_ramesh';
    const result = await db.query(
      `SELECT * FROM notifications WHERE farmer_id = $1 ORDER BY created_at DESC LIMIT 20`,
      [farmerId]
    );

    const notifications = result.rows.map((n: any) => ({
      id: n.id,
      type: n.type,
      severity: n.severity,
      titleKey: n.title_key,
      descriptionKey: n.description_key,
      icon: n.icon,
      timestamp: n.created_at,
      read: n.read,
      actionUrl: n.action_url,
    }));

    res.json({ success: true, notifications });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export async function markAsRead(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params;
    await db.query(`UPDATE notifications SET read = TRUE WHERE id = $1`, [id]);
    res.json({ success: true, message: 'Notification marked as read' });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export async function markAllAsRead(req: AuthRequest, res: Response): Promise<void> {
  try {
    const farmerId = req.farmerId || 'farmer_ramesh';
    await db.query(`UPDATE notifications SET read = TRUE WHERE farmer_id = $1`, [farmerId]);
    res.json({ success: true, message: 'All notifications marked as read' });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}
