import { Response } from 'express';
import { AuthRequest } from '../middleware/auth.js';
import { soilService } from '../services/soilService.js';

export async function getLaboratories(_req: AuthRequest, res: Response): Promise<void> {
  try {
    const labs = await soilService.getLaboratories();
    res.json({ success: true, laboratories: labs });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export async function getLabById(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params;
    const lab = await soilService.getLabById(id);
    if (!lab) {
      res.status(404).json({ success: false, error: 'Laboratory not found' });
      return;
    }
    res.json({ success: true, laboratory: lab });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export async function createTestRequest(req: AuthRequest, res: Response): Promise<void> {
  try {
    const farmerId = req.farmerId || req.userId || 'farmer_ramesh';
    const { farmId, fieldId, cropName, labId, sampleCollectionDate, testTypes, testingMode, trackingNotes } = req.body;

    if (!cropName || !labId) {
      res.status(400).json({ success: false, error: 'cropName and labId are required' });
      return;
    }

    const request = await soilService.createRequest({
      farmerId,
      farmId,
      fieldId,
      cropName,
      labId,
      sampleCollectionDate,
      testTypes: testTypes || ['pH', 'EC', 'OC', 'N', 'P', 'K'],
      testingMode,
      trackingNotes,
    });

    res.status(201).json({
      success: true,
      message: 'Soil test request created successfully',
      request,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export async function getFarmerRequests(req: AuthRequest, res: Response): Promise<void> {
  try {
    const farmerId = (req.query.farmerId as string) || req.params.farmerId || req.farmerId || 'farmer_ramesh';
    const requests = await soilService.getFarmerRequests(farmerId);
    res.json({ success: true, requests });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export async function getRequestById(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params;
    const request = await soilService.getRequestById(id);
    if (!request) {
      res.status(404).json({ success: false, error: 'Test request not found' });
      return;
    }
    res.json({ success: true, request });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export async function updateRequestStatus(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params;
    const { status, notes } = req.body;

    if (!status) {
      res.status(400).json({ success: false, error: 'status is required' });
      return;
    }

    const updated = await soilService.updateStatus(id, status, notes);
    res.json({ success: true, request: updated });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export async function getLatestReport(req: AuthRequest, res: Response): Promise<void> {
  try {
    const farmerId = req.params.farmerId || req.farmerId || 'farmer_ramesh';
    const report = await soilService.getLatestReport(farmerId);
    res.json({ success: true, report });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export async function getReportsHistory(req: AuthRequest, res: Response): Promise<void> {
  try {
    const farmerId = req.params.farmerId || req.farmerId || 'farmer_ramesh';
    const history = await soilService.getReportsHistory(farmerId);
    res.json({ success: true, history });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export async function getSensorReading(req: AuthRequest, res: Response): Promise<void> {
  try {
    const fieldId = req.params.fieldId || 'field_1';
    const sensor = await soilService.getSensorReading(fieldId);
    res.json({ success: true, sensor, reading: sensor });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}
