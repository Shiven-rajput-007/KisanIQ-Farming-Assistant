import { Response } from 'express';
import { decisionEngine } from '../services/decisionEngine.js';
import { AuthRequest } from '../middleware/auth.js';

export async function getDailyRecommendations(req: AuthRequest, res: Response): Promise<void> {
  try {
    const farmerId = req.farmerId || 'farmer_ramesh';
    const recommendations = await decisionEngine.generateRecommendations(farmerId);
    res.json({ success: true, recommendations });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export async function completeAction(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params;
    const success = await decisionEngine.markActionCompleted(id);
    if (!success) {
      res.status(404).json({ success: false, error: 'Action not found' });
      return;
    }
    res.json({ success: true, message: 'Action marked as completed' });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}
