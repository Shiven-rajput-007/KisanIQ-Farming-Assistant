import { Router } from 'express';
import { getMarketComparison, createSellOrder } from '../controllers/marketController.js';
import { optionalAuth } from '../middleware/auth.js';

const router = Router();

router.get('/comparison', optionalAuth, getMarketComparison);
router.post('/orders', optionalAuth, createSellOrder);

export default router;
